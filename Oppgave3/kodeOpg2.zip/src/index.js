import "./styles.scss";

const app = document.getElementById('app');
app.innerHTML = '<h1>Hei, dette er til oppgave 2 i oblig 3</h1>';
console.log('test');
